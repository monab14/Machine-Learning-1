# Marketing Campaign for Banking Products

A Machine Learning Internship Project for Machine Learning course offered by Internship Studio

The objective of this Project is to predict the likelihood of a liability customer buying personal loans.

## Dataset Used in Project

Link to download - https://www.kaggle.com/itsmesunil/bank-loan-modelling/download
